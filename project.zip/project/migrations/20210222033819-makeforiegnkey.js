'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    //boards에서 user_id 외래키 지정
    await queryInterface.addColumn('boards', 'user_id', { 
      type:Sequelize.INTEGER
    });

    // 외래키 관련 설정
    /*
    await queryInterface.addConstraint('boards', {
      fields: ['user_id'],
      type: 'foreign key',
      name: 'boards_user_id_fk',
      reference: {
        table: 'users',
        'field': 'id'
      },
      onDelete: 'cascade',
      onUpdate: 'cascade'.
    })
    */
    
    // files에서 board_id 외래키 지정
    await queryInterface.addColumn('files', 'board_id', { 
      type:Sequelize.INTEGER
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeColumn('boards','user_id');
    await queryInterface.removeColumn('files','board_id');
  }
};
