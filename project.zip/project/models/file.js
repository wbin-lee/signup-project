'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class file extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // 파일들은 게시글에 종속된다. N:1
      models.file.belongsTo(models.board, {foreignKey: 'board_id'});
    }
  };
  file.init({
    filename: DataTypes.STRING,
    originalname: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'file',
  });
  return file;
};