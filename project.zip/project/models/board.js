'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class board extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // 게시글 여러개는 user에 종속된다.(N:1)
      models.board.belongsTo(models.user, {foreignKey:'user_id'});
      // 게시글은 파일 여러개를 가질 수 있다(1:N)
      models.board.hasMany(models.file, {foreignKey:'board_id'});
    }
  };
  board.init({
    title: DataTypes.STRING,
    content: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'board',
  });
  return board;
};